#!/bin/bash
set -x
# Set the repo dir
REPO_DIR=~/freedv_ptt

# Navigate to the local repo
cd $REPO_DIR

# Fetch
git fetch

# Get hashes
LOCAL_HASH=$(git rev-parse HEAD)
REMOTE_HASH=$(git rev-parse @{u})

# Compare the local and remote hashes
if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
    echo "New update found. Updating..."

    # Pull the latest changes from the remote repository
    git pull

    # Find the latest .deb file in the repository
    DEB_FILE=$(ls -t | grep .deb | head -n 1)

    if [ -z "$DEB_FILE" ]; then
        echo "No .deb file found in the repository."
        exit 1
    fi

    # Install the .deb file
    sudo dpkg -i $DEB_FILE

    echo "Update completed."
else
    echo "Already up-to-date."
fi